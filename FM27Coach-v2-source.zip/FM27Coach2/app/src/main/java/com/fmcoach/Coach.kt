package com.fmcoach

data class Finding(val good: Boolean, val title: String, val cause: String, val fix: String = "")

/** Asisten pelatih berbasis aturan: Temuan -> Penyebab (dari data) -> Solusi. */
object Coach {
    private val DEF = setOf("DR", "DL", "DC", "WBR", "WBL")
    private fun f2(d: Double) = "%.2f".format(d)
    private fun idx(m: Match, club: String) = when { m.home.equals(club, true) -> 0; m.away.equals(club, true) -> 1; else -> -1 }
    private fun v(m: Match, k: String, i: Int): Double? = m.team[k]?.let { if (i == 0) it.first else it.second }

    fun report(m: Match, club: String): List<Finding> {
        val i = idx(m, club)
        if (i < 0) return listOf(Finding(false, "Kode klub \"$club\" tidak cocok", "Match ini: ${m.home} vs ${m.away}", "Isi kode klub Anda persis seperti di bar skor game."))
        val j = 1 - i
        val out = mutableListOf<Finding>()
        val xg = v(m, "xg", i); val oxg = v(m, "xg", j); val shots = v(m, "shots", i); val poss = v(m, "poss", i)
        val cra = v(m, "cra", i); val crc = v(m, "crc", i)
        val won = if (i == 0) m.hg > m.ag else m.ag > m.hg

        if (xg != null && oxg != null) {
            if (xg < oxg * 0.6) out += Finding(false, "Kualitas peluang kalah dari lawan", "xG ${f2(xg)} vs ${f2(oxg)}" + if (won) " (menang, tapi sulit diulang)" else "",
                "Kurangi tembakan jarak jauh, minta masuk lebih sabar ke kotak penalti, dan rapikan transisi bertahan.")
            else if (xg > oxg * 1.5) out += Finding(true, "Peluang lebih berkualitas dari lawan", "xG ${f2(xg)} vs ${f2(oxg)}")
        }
        if (poss != null && xg != null && poss >= 55 && xg < 0.8)
            out += Finding(false, "Menguasai bola tapi tidak menembus", "Penguasaan ${poss.toInt()}% dengan xG hanya ${f2(xg)}",
                "Naikkan tempo, umpan lebih langsung ke depan, dan tambah overlap/underlap di sayap.")
        if (shots != null && xg != null && shots >= 10 && xg / shots < 0.06)
            out += Finding(false, "Banyak tembakan bernilai rendah", "${shots.toInt()} tembakan, rata-rata ${f2(xg / shots)} xG", "Kurangi 'Shoot on Sight', buat tembakan dari area lebih dekat gawang.")
        if (cra != null && crc != null && cra >= 8 && crc / cra < 0.25)
            out += Finding(false, "Umpan silang tidak efektif", "${crc.toInt()} dari ${cra.toInt()} berhasil", "Kurangi frekuensi crossing, ubah winger jadi inside forward, atau pasang target man bila memang mau main sayap.")

        val pl = m.players
        pl.filter { it.pos in DEF && it.v[0] >= 25 && it.passAcc < 75 }.forEach {
            out += Finding(false, "${it.name} sering kehilangan bola", "Akurasi umpan ${it.passAcc.toInt()}% dari ${it.v[0]} umpan",
                "Turunkan risk passing/pakai umpan lebih pendek, atau ganti dengan bek yang Passing/Composure lebih tinggi.")
        }
        pl.filter { it.key >= 4 || (it.rating >= 8 && it.ass + it.v[15] > 0) }.forEach {
            out += Finding(true, "${it.name} tampil menonjol", "${it.key} umpan kunci, ${it.ass} assist, rating ${it.rating}")
        }
        pl.filter { it.kon < 82 }.forEach { out += Finding(false, "${it.name} kondisi rendah (${it.kon}%)", "", "Pertimbangkan rotasi di match berikutnya.") }
        if (out.isEmpty()) out += Finding(true, "Tidak ada temuan menonjol", "Data match terbaca, tidak ada aturan yang terpicu.")
        return out
    }

    /** Pola yang hanya terlihat jika riwayat beberapa match digabung. */
    fun patterns(ms: List<Match>, club: String): List<String> {
        val mine = ms.filter { idx(it, club) >= 0 }
        if (mine.size < 2) return emptyList()
        val out = mutableListOf<String>()
        var att = 0.0; var ok = 0.0
        mine.forEach { m -> val i = idx(m, club); att += v(m, "cra", i) ?: 0.0; ok += v(m, "crc", i) ?: 0.0 }
        if (att >= 15 && ok / att < 0.25) out += "Umpan silang hanya ${(100 * ok / att).toInt()}% berhasil dalam ${mine.size} match. Ganti pola serangan sayap."
        val low = mine.count { m -> val i = idx(m, club); val a = v(m, "xg", i); val b = v(m, "xg", 1 - i); a != null && b != null && a < b }
        if (low >= mine.size * 0.6) out += "xG Anda lebih rendah dari lawan di $low dari ${mine.size} match. Masalahnya struktural, bukan nasib."
        return out
    }
}
